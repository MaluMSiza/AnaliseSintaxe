/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package n1b1lp2;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author maria
 */
public class Cargo extends Funcionario {
    Long codigo;
    String nome;

    
}
